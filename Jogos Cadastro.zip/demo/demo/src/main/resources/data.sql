-- Adicionando um novo jogo
INSERT INTO GAME (ID, TITLE, DESCRIPTION, RELEASE_YEAR, GENRE, RATING, MULTIPLAYER)
VALUES (1, 'The Legend of Zelda: Breath of the Wild', 'Aventura epica em mundo aberto', 2017, 'Acao/Aventura', 9.5, true);

-- Adicionando outro jogo
INSERT INTO GAME (ID, TITLE, DESCRIPTION, RELEASE_YEAR, GENRE, RATING, MULTIPLAYER)
VALUES (2, 'The Witcher 3: Wild Hunt', 'RPG de mundo aberto com historia envolvente', 2015, 'RPG', 9.8, false);

-- Adicionando outro jogo
INSERT INTO GAME (ID, TITLE, DESCRIPTION, RELEASE_YEAR, GENRE, RATING, MULTIPLAYER)
VALUES (3, 'GTA V', 'RPG de mundo aberto com historia envolvente', 2013, 'Acao', 7, true);
